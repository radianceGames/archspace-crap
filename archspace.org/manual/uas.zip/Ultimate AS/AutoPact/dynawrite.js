
//     JAVASCRIPT INCLUDE FILE - (c) J R Stockton  >= 2003-03-25
//             http://www.merlyn.demon.co.uk/include1.js
//       Routines may be copied, but URL must not be linked to.

var Inc1T=0

function VSF() { document.writeln( // After Michael Donn
  ' <a href="view-source:'+this.location+'">View Source File<\/a>') }


// DynWrite(target, text) (Jim Ley) works on controls, after page load :
// it is a computed function :

// Classify browser :

function GetDocVars() { // set 4 Globals; called in include1.js
  nCheck = 0
  if (DocDom = (document.getElementById?true:false))
                                           nCheck++ // NS6 also IE5
  if (DocLay = (document.layers?true:false))
                                           nCheck++ // NS4
  if (DocAll = (document.all?true:false))
                                           nCheck++ // IE4
  }  GetDocVars() // call *here*

// if (nCheck!=1) alert('Browser classification problem!  nCheck = ' +
//  String(nCheck) + '\nPlease let me know how the page works and what' +
//  ' the\nbrowser is; and, if possible, what needs to be done about it.')
function ReportDocVars() {
  if (nCheck==0)
    document.write(' None of DocDom, DocLay, DocAll is set;',
      ' Dynamic Write will fail.'.italics(), '<p>')
  if (DocDom) document.write(' DocDom is set. ')
  if (DocLay) document.write(' DocLay is set. ')
  if (DocAll) document.write(' DocAll is set. ') }

function TableDocVars() {
  document.writeln('<br><br><table summary="Browser class info"',
    ' bgcolor=blue align=center cellpadding=10 border=4>',
    '<tr><th bgcolor=wheat>For the displaying computer :</th>',
    '</tr><tr><td bgcolor=gainsboro align=center>',
    'Your browser gives<br>',
    '<b>DocAll = ', DocAll, ' ; DocDom = ', DocDom,
    ' ; DocLay = ', DocLay, '.</b><br>',
    'Check : ', nCheck, ' browser classification(s) set.',
    '</td></tr></table>') }


// Define Function DynWrite(Where, What) to suit browser :
DocStr=''
if (DocLay) DocStr="return document.layers['NS_'+id]"
if (DocAll) DocStr="return document.all[id]"
if (DocDom) DocStr="return document.getElementById(id)"
GetRef=new Function("id", DocStr)

// DocLay = true ; DocAll = DocDom = false // Simulate NS4.7
DynWarn = 0

if (DocStr=='') { DynWrite=new Function("return false") } else {
  if (DocAll || DocDom) {
    DynWrite=new Function("id", "S", "GetRef(id).innerHTML=S; return true")
    }
// if (DocLay) DynWrite=new Function("id", "S", "var x=GetRef(id).document;"+
//  "x.open('text/html'); x.write(S); x.close(); return true")
if (DocLay) DynWrite=new Function(
    "if (0==DynWarn++)"+
    " alert('DynWrite not supported in \".layers\" browsers');"+
    "return false")
 }


function NoDynLay() {
  if (DocLay) document.writeln(
    '<p><i>Dynamic Writing in a ".layers" browser such as yours ',
    'is difficult and I cannot now test it.  Therefore, ',
    'I don\'t now attempt it. An alert will be given in the ',
    'first use in each load/reload of a page.<\/i>') }

// DynWrite() end.



// General Utilities :

function LS(x) {return String(x).replace(/\b(\d)\b/g, '0$1')}

function LZ(x) {return(x<0||x>9?"":"0")+x}

function LZZ(x) {return(x<0||x>99?x:"0"+LZ(x))}

if (String.prototype && !String.prototype.substr) {
  String.prototype.substr =
    new Function("J", "K", "return this.substring(J, J+K)") }

function TrimS() { // Grant Wagner
  return (this.toString() ?
    this.toString().replace(/\s+$|^\s*/g, "") : "") }
String.prototype.trim = TrimS

function Sign(y) {return(y>0?'+':y<0?'-':' ')}

function Prfx(Q, L, c) { var S = Q+'' // ??
  // if (!c) var c = ' '
  if (c.length>0) while (S.length<L) { S = c+S } ;
  return S }

function StrU(X, M, N) { // X>=0.0
  var T, S=new String(Math.round(X*Number("1e"+N)))
  if (/\D/.test(S)) { return ''+X }
  with (new String(Prfx(S, M+N, '0')))
    return substring(0, T=(length-N)) + '.' + substring(T) }

function StrT(X, M, N) { return Prfx(StrU(X, 1, N), M+N+2, ' ') }

function StrS(X, M, N) { return Sign(X)+StrU(Math.abs(X), M, N) }

function StrW(X, M, N) { return Prfx(StrS(X, 1, N), M+N+2, ' ') }

if (!Number.toFixed) { // 20030313
  Number.prototype.toFixed = // JL
    new Function('n', 'return StrS(this, 1, n)') }

function SigFigExp(X, N) { // N<22
  if (X==0) return SigFigExp(1, N).replace(/\+1/, ' 0')
  var p = Math.floor(Math.log(Math.abs(X))/Math.LN10)
  if (!isFinite(p)) return X
  return (X>0?'+':'') +
    String(Math.round(X*Math.pow(10, N-p-1))).
      replace(/(\d)/, "$1.") +
    (p>=0?"e+":"e-") + LZ(Math.abs(p)) } // All OK?


function Div(a, b) { return Math.floor(a/b) }

function Mod(a, b) { return a-Math.floor(a/b)*b }


var IxIt=0, BoxX=68


function Depict(X, Y, S, Hue) { // String S is shown and returned
  if (!Hue) Hue = 'blue'
  var AutoID = "Auto" + ++IxIt
  document.writeln("<form name=", AutoID, ">",
    "<table align=center bordercolor=", Hue, " border=3><tr><td>",
    "<textarea name=N cols=", X, " rows=", Y, " readonly>",
    "<\/textarea><\/td><\/tr><\/table><\/form>")
  document.forms[AutoID].elements["N"].value = S
  return S }


function ShowFF() { // Args are functions, last Arg is box height
  var Len = --arguments.length, S = ''
  for (var j=0 ; j<Len ; j++) {
    if (j>0) S += "\n\n"
    S += arguments[j].toString() }
  Depict(BoxX, arguments[Len], S, 'green') }


function ShowDo(Fn, Ht) {
  Depict(BoxX, Ht, Fn.toString(), 'red' ) ; Fn() }


function eIVSF() {
  Depict(46, 1, "  For the code, view the source of this page", 'black') }

var Inc1B=0 // end.

