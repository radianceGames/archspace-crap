ASScript Center by Grayson Carlyle

This is open source, so feel free to edit anything you want; just give credit where credit is due.

Version Changes:
	v1.0 The Original
	v1.1 
		-Some minor visual changes
		-Added Refresh to Auto Expedition.  Only use this if you find that you're waking up logged out.
	v2.0
		-Based on an extended AS menu thanks to embryodead
		-New colour scheme to match AS
		-Default Spy Master Action is Steal Tech
	v2.1
		-Fixed Fleeters return page when it was finished the fleeting loop
		-Fixed the stop button in auto expedition so it will stop refresh as well
	v3.0
		-Numerous updates and fixes by embryodead - see the AS+ ReadMe for details

Credit:
Planet Manager originally by Dave McW
	Modifications by Quantum and Admiral J
	Revamped by d-Zrone
	Fixed and Organized by Grayson Carlyle

Auto Pact originally by Dave McW
	Revamped by d-Zrone
	Organized by Grayson Carlyle

Fleeter by d-Zrone

Quick Block a modification of Planet Manager by Grayson Carlyle

Spy Master a modification of Planet Manager by Grayson Carlyle

Ship Designer by Unknown
	Corrected for AS 2003 by Grayson Carlyle

Auto Expedition by Grayson Carlyle