AS+ 3.02

Compiled by Grayson Carlyle & embryodead

To use this just login into Archspace and open index.html from AS+ folder. You can turn off the right-hand combat sidebar from the menu (under OPTIONS).

AS+ is a toolset for Archspace 2004 containing:

	- ASScript Center 2.1 compiled by Grayson Carlyle, a toolset with updated or new scripts:
		Planet Management++
		Autopact
		Fleeter
		Ship Designer
		Spy Master
		Auto Expedition
		Quick Block
	- Updates and fixes to the above by embryodead
	- More scripts by embryodead:
		Message Bot
		Autoinvestor
		Commie Manager
	- Menu links, shortcuts, charts and optional combat sidebar by embryodead

The newest version of this toolset is always available at http://avn.beheadedstraw.net/asplus.zip
If you have any questions, ask embryodead in #archspace on IRC or y4ho0_dead@hotmail.com on MSN (I don't use this e-mail though).

Changes in 3.02
- added Commie Manager 1.2
- updated some Chart info ie. with new projects and weapons
- re-organised the files

Changes in 3.01
- updated Autoinvestor to 1.1 (it can now invest into planets as well, using the new global pool; added option to halve the investment for Evintos)
- updated scripts' default delay from 8 to 5 minutes
- updated some Chart info

* * *

This is open source, so feel free to edit anything you want; just give credit where credit is due.
		
Credits:

Planet Manager originally by DaveMcW
	- Modifications by Quantum and Admiral J
	- Revamped by d-Zrone
	- Fixed and Organized by Grayson Carlyle

Autopact originally by DaveMcW
	- Revamped by d-Zrone
	- Organized by Grayson Carlyle
	- Updated and fixed by embryodead

Fleeter by d-Zrone
	- Updated and fixed by embryodead

Quick Block a modification of Planet Manager by Grayson Carlyle

Spy Master a modification of Planet Manager by Grayson Carlyle

Ship Designer by unknown, corrected for AS 2003 by Grayson Carlyle

Auto Expedition by Grayson Carlyle
	- Updated by embryodead

Message Bot a modification of Autopact by embryodead

Autoinvestor by embryodead

Commie Manager by embryodead